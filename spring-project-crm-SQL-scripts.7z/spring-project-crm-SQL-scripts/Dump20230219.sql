-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: spring_project_security
-- ------------------------------------------------------
-- Server version	8.0.32

CREATE DATABASE  IF NOT EXISTS `spring_project_security`;
USE `spring_project_security`;

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `authorities`
--

DROP TABLE IF EXISTS `authorities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authorities` (
  `username` varchar(50) NOT NULL,
  `authority` varchar(50) NOT NULL,
  UNIQUE KEY `authorities_idx_1` (`username`,`authority`),
  CONSTRAINT `authorities_ibfk_1` FOREIGN KEY (`username`) REFERENCES `users` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authorities`
--

LOCK TABLES `authorities` WRITE;
/*!40000 ALTER TABLE `authorities` DISABLE KEYS */;
INSERT INTO `authorities` VALUES ('jelena','ROLE_EMPLOYEE'),('jelena','ROLE_MANAGER'),('john','ROLE_EMPLOYEE'),('mary','ROLE_EMPLOYEE'),('mary','ROLE_MANAGER'),('nikola','ROLE_ADMIN'),('nikola','ROLE_EMPLOYEE'),('susan','ROLE_ADMIN'),('susan','ROLE_EMPLOYEE'),('test','ROLE_EMPLOYEE');
/*!40000 ALTER TABLE `authorities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` char(68) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES ('jelena','{bcrypt}$2a$10$EzW.qRDT6Pga2PxFWZ4nuO0d3uyVl0Y.v7TrpMbTH4HokJ3gpgXSi',1),('john','{bcrypt}$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K',1),('mary','{bcrypt}$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K',1),('nikola','{bcrypt}$2a$10$hW8rExof/hY9VZqCk5JHnOhzQtKZygN31iPKatWMYQHsYuACZt1GS',1),('susan','{bcrypt}$2a$04$eFytJDGtjbThXa80FyOOBuFdK2IwjyWefYkMpiBEFlpBwDH.5PM0K',1),('test','{bcrypt}$2a$10$/AAhH25eS8stSAdpoCMgBeWtpyHHm/2OGuuHN4Zh.hkMjyiElhJNa',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-19 21:24:11
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: spring_project
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Nikola','Stankov','hernikola@icloud.com','Las Vegas','Las Vegas Blvrd'),(2,'Demario','Morar','zkulas@example.com','North Kurt','5586 Marcia Village Suite 753\nWizashire, PA 57724-'),(3,'Lillian','Runolfsdottir','jerad02@example.org','Hellerborough','3024 Rosella Lake\nNorth Bernadettebury, CO 19877-3'),(4,'Mathew','Haag','durgan.celia@example.org','South Omerland','2638 Joelle Grove Apt. 176\nWarrenmouth, MS 51843-4'),(5,'Theodora','Mertz','mose.bailey@example.com','East Lenny','848 Doyle Corners Suite 323\nFerryfurt, KY 30617'),(7,'Karina','Hodkiewicz','dandre.mann@example.com','Wittingburgh','72486 Gerry Bypass Apt. 859\nNorbertoville, HI 7968'),(8,'Kaleb','Dicki','bennie76@example.org','McCulloughbury','963 Augustine Fields\nGradyberg, SD 73459-7135'),(9,'Rod','Prosacco','nola71@example.com','Robelland','19735 Sadie Pine Apt. 139\nRuthtown, AK 45539-3706'),(10,'Nicklaus','Rowe','janis26@example.com','Lake Gabriellaview','296 Koepp Drive\nAdelechester, MO 50113-0619'),(11,'Daryl','Turcotte','jonathon49@example.com','East Antwonchester','090 Elda Fields\nMcKenziefurt, ID 15642'),(12,'Cole','Mitchell','wolf.jovani@example.org','Santiagoside','87721 Anderson Loop\nDenesikport, IA 64280'),(13,'Quinn','Raynor','bednar.marta@example.org','Miastad','007 Hyatt Tunnel\nRoobhaven, IL 19879-8660'),(14,'Precious','DuBuque','yhand@example.com','Jerdeburgh','9739 Samir Passage\nSchillerstad, OK 16246-5328'),(15,'Laney','Wintheiser','hlang@example.org','Gwenbury','66308 Watsica Trafficway Suite 388\nAntoniettamouth'),(16,'Destin','Windler','kody64@example.net','New Keaganfort','4577 Eddie Row\nSouth Vergieport, FL 58658'),(17,'Louie','Hirthe','aurore63@example.net','North Manley','807 Blake Flat Apt. 375\nHoppefurt, DC 16397-5134'),(18,'Beaulah','Rippin','uheathcote@example.org','West Dexterville','15281 Elwyn Harbors\nMurazikborough, TX 33043-8096'),(19,'Zion','Farrell','walter48@example.net','Windlerborough','44196 Robyn Junction Suite 089\nWest Arlene, TN 085'),(21,'Anastasia','Hammes','brandt.altenwerth@example.net','Kovacekborough','629 Dare Run\nEduardochester, SC 19174-4940'),(22,'Brianne','Schuppe','brunte@example.org','Port Jacklyn','39880 Alison Brook Suite 707\nWest Charles, OR 2268'),(24,'Sigmund','Stark','roberts.kayla@example.com','Kreigerburgh','37814 Bruen Parkways Apt. 186\nEast Lelahton, NM 56'),(25,'Gaylord','Schumm','herman.meda@example.org','East Hildegardhaven','69742 Retha Isle\nNigelville, FL 37018'),(26,'Roosevelt','Becker','douglas.marc@example.com','Langoshland','39983 Chanel Estates Apt. 974\nPort Adalineburgh, P'),(27,'Lula','Rippin','johann.yost@example.com','Yazminchester','49986 Schultz Streets\nSouth Kianaville, OR 83856'),(28,'Humberto','Rath','wendell86@example.net','Reynoldshaven','964 Aufderhar Keys\nPort Estellfurt, OR 48974-9211'),(29,'Jacquelyn','Blanda','jaqueline18@example.net','Mertiemouth','472 Jennifer Overpass\nEast Sandrine, SD 40691'),(30,'Arely','Jenkins','brenna.lindgren@example.com','Colestad','3829 Donna Circle Apt. 303\nKonopelskichester, MT 1'),(31,'Oliver','Schamberger','buddy.shields@example.org','Lake Micah','2984 Mayer Club Suite 843\nFarrelltown, FL 89601-89'),(32,'Katrine','Kuhn','whodkiewicz@example.net','Olsonview','733 Gennaro Garden\nKarelleport, NE 67901-6514'),(33,'Malachi','Konopelski','wschultz@example.net','South Caden','765 Maria Shore\nLangoshmouth, SD 85493'),(34,'Sydnie','Conn','walter.christina@example.org','Feeneyberg','572 Kay Meadow Suite 865\nLake Winifred, VA 72614'),(35,'Samanta','Brown','ypollich@example.net','East Shania','16172 Johathan Street Apt. 750\nPadbergport, RI 616'),(36,'Isai','Jacobi','kamron92@example.com','Lake Mckaylafort','40953 Cathryn Creek Suite 108\nRosenbaumview, PA 36'),(37,'Randall','Schmeler','haag.lamont@example.net','Port Daniellechester','57384 Goldner Fort\nPort Linwoodstad, NY 91562'),(38,'Oran','Stehr','mbrakus@example.com','Champlinshire','26727 Orpha Estates Suite 479\nSouth Unaberg, IL 91'),(39,'Gwendolyn','Crooks','dion02@example.net','Mullermouth','42777 Mohammed Locks Suite 920\nPort Elenoramouth, '),(40,'Mozelle','Howe','jocelyn14@example.com','South Brandtberg','71183 Hansen Lock Suite 717\nPietrohaven, NM 26143'),(41,'Kasandra','Ledner','uhamill@example.net','Kuhlmanton','966 Ward Falls Apt. 486\nStantonmouth, TN 79741'),(42,'Kennith','Rolfson','augustine.trantow@example.org','Ullrichville','779 Niko Vista Suite 881\nFunkbury, NY 65787'),(43,'Isai','Rodriguez','leannon.katelin@example.com','Jamarchester','704 Pagac Plains Apt. 748\nFeilton, IA 79261-1704'),(44,'Mertie','Kreiger','clifton.schuster@example.com','Lake Darleneshire','9956 Rohan Square Suite 690\nEldaside, CT 52838-760'),(45,'Turner','Abernathy','reagan.beatty@example.com','Port Aftonland','4252 Pearl Trail\nGailtown, VT 43547'),(46,'Lazaro','Kassulke','nikita56@example.com','Corwinberg','5069 Ratke Gardens Suite 740\nKautzerview, HI 02699'),(47,'Walter','Dietrich','archibald.heidenreich@example.net','Hamillmouth','4013 Torphy Club Suite 395\nPort King, PA 27966'),(48,'Lazaro','Conn','bbradtke@example.net','Lake Arnoldo','7861 Stanton Loaf Apt. 842\nHartmannmouth, OR 38979'),(49,'Alexane','Will','richie30@example.org','Rogerschester','1048 Waters Unions Apt. 600\nDonstad, NY 39319'),(50,'Elise','Pfeffer','joany80@example.com','Lake Zoey','654 Kerluke Island\nJerroldberg, TX 18574-2560'),(51,'Noemy','Nienow','jaime22@example.org','North Stella','2897 Cummerata Lodge Suite 451\nKautzerton, RI 9224'),(52,'Tyreek','Rolfson','hortense93@example.org','Hermanton','583 Dayton Plains Apt. 836\nWisozkview, MN 19114'),(53,'Brett','Ortiz','vmclaughlin@example.org','East Octavia','258 Luettgen Stream\nRyanland, WV 42853'),(54,'Samanta','Rogahn','nestor19@example.com','Willmsbury','51721 Gusikowski Centers Suite 822\nNorth Tayaview,'),(56,'Alford','Anderson','grady.cummings@example.com','New Kristy','963 Crooks Point\nAngelineberg, VT 07556-3321'),(57,'Christopher','Franecki','glennie20@example.net','North Valerieland','1693 Lesly Pines\nEast Lucyton, NH 14423'),(58,'Nicholas','Lakin','bartell.mikel@example.net','Wolffhaven','54745 Schumm Common\nKemmershire, MS 99532-6352'),(59,'Axel','Herzog','waelchi.karen@example.com','New Garnetthaven','80703 Nikolas Gardens Apt. 049\nYundtmouth, NV 2427'),(60,'Karley','Torphy','wcollier@example.com','Robertsfort','7852 Becker Via\nSouth Esmeralda, NY 73435-0519'),(61,'Carrie','VonRueden','marjolaine.osinski@example.org','South Arianna','293 Clemmie Lakes\nNew Leopoldbury, IA 48164'),(62,'Kayley','Gutkowski','bwilkinson@example.org','Beattyburgh','99684 Dave Passage\nEast Rodolfo, ND 66496-0142'),(63,'Gussie','Littel','pwalsh@example.com','Simonischester','8256 D\'Amore Turnpike\nLake Ollie, IL 02597'),(64,'Jed','Johnston','yazmin.wilkinson@example.org','Batzbury','84792 Dion Estates\nLlewellyntown, CA 65094-9238'),(65,'Clair','Cartwright','ondricka.bryana@example.net','Macejkovicberg','673 Verdie Mall\nNew Charleshaven, MA 04490'),(66,'Soledad','Lesch','bethel43@example.com','Mosciskishire','9383 Joey Lane Suite 191\nLebsackbury, DE 63453-954'),(67,'Karl','Hermann','beier.chandler@example.net','New Jayson','7420 Stoltenberg Knoll Suite 932\nWest Ryleefort, N'),(68,'Tyreek','Boyle','alda.jacobs@example.net','Kuphalport','048 Jerrod Harbors\nNew Kyleighberg, OR 57851-7872'),(69,'Olen','VonRueden','leopoldo.sawayn@example.com','East Glennie','3007 Gerhold Gardens Apt. 326\nLake Skyla, KY 76811'),(70,'Jarrett','Cassin','llangworth@example.org','Ferrytown','238 Ludwig Squares Suite 089\nHicklemouth, FL 77383'),(71,'Hazle','Waelchi','d\'amore.stanton@example.org','Lake Romatown','0401 Mckenna Islands\nBartonmouth, PA 82557'),(73,'Quinton','Sawayn','marquis.bins@example.net','Lake Anthony','981 Fahey Tunnel\nSouth Dexterview, MO 80503-8273'),(75,'Justus','Erdman','nicklaus09@example.org','New Wilfredostad','6014 Terence Drive\nEast Elliottmouth, TN 35482'),(76,'Rachel','Mitchell','torrey85@example.org','Littleport','5441 Laurie Brooks Apt. 617\nNew Emanuel, TN 75317-'),(77,'Litzy','Kassulke','shaun.hintz@example.org','Rogahnview','23956 Jenkins Drives Apt. 344\nLake Myrtleland, HI '),(78,'Rhea','Reichel','orempel@example.net','Dooleyfurt','9576 Sage Knolls Suite 780\nNeilbury, NE 86292-6605'),(79,'Makenna','Ullrich','arthur.rempel@example.com','Britneyburgh','76557 Valerie Dale\nOlsonbury, CO 45401'),(80,'Maxie','Zboncak','adietrich@example.net','Rodrigofurt','6896 Eliseo Lock Suite 226\nGibsonborough, OH 51089'),(81,'Glenda','Heathcote','marshall12@example.net','South Jaronstad','3109 Lemke Keys\nEast Janniechester, AK 04393'),(82,'Madilyn','O\'Kon','oweber@example.net','Port Cecile','035 Kaela Road Suite 967\nNorth Verona, SC 98532'),(83,'Troy','Tremblay','reginald89@example.net','New Emerymouth','84820 Zoie Shore\nSouth Trevorborough, WA 08708'),(84,'Deron','Wisozk','emmitt83@example.org','South Joaquintown','531 Rosalind Creek\nFisherchester, MS 75987-0652'),(85,'Piper','Homenick','jamir53@example.net','McDermottmouth','96250 Considine Via Apt. 084\nNorth Matilda, ME 455'),(86,'Rhianna','McClure','zbeier@example.com','East Jessikafort','0907 Hartmann Isle Apt. 119\nStehrland, ID 50690'),(87,'Kristina','Raynor','hklein@example.com','Hansentown','6847 Hyatt Plaza Apt. 020\nLake Reginald, OK 03453-'),(88,'Chad','Romaguera','zulauf.kyra@example.org','Cruickshankburgh','1101 Cecelia Course Apt. 798\nHahnchester, FL 93931'),(89,'Christian','Pouros','paige.windler@example.net','North Carlitown','1957 Hintz Squares\nSouth Alexanne, NM 68298'),(90,'Winfield','Gutkowski','monserrat97@example.org','Reillyshire','17055 Sauer Square\nNew Marianne, ND 01699-6833'),(91,'Magali','Ondricka','danyka.mckenzie@example.org','Aishashire','0333 Leffler Street\nNorth Madalyn, NJ 90164-8216'),(92,'Dante','Maggio','aleannon@example.net','Welchfort','234 Magali Wall\nSouth Paytonview, VT 28427-0574'),(93,'Maia','Nolan','finn63@example.org','North Paigeborough','173 Arne Islands Suite 178\nFinntown, AR 72623-8753'),(94,'Noelia','Mohr','dashawn04@example.org','Harveyfort','086 Camilla Shoals Apt. 504\nEast Abigailport, AR 3'),(95,'Dock','Runte','goldner.roel@example.com','New Preston','38879 Carolyn Groves Apt. 814\nFerrymouth, NY 78925'),(96,'Zetta','Robel','vidal.walsh@example.net','Port Albertha','75175 Amelia Run\nPort Braeden, NY 22557'),(97,'Willow','Schuster','micah21@example.org','VonRuedenborough','665 Abdiel Corner Suite 011\nNew Edythe, VA 78714'),(98,'Mariela','Predovic','o\'reilly.bessie@example.net','McKenzieshire','15436 Vella Pines Suite 728\nBraunshire, UT 79951'),(99,'Hannah','Thompson','dejon33@example.net','Lake Jedidiahtown','8399 Gutkowski Land\nNew Celestineland, IN 39046-12'),(100,'Cassandra','Purdy','greenfelder.tanner@example.com','Anastaciofurt','857 Esta Stream\nProhaskaville, GA 53107-8997'),(101,'Renee','Wolf','jaron99@example.org','Port Clay','822 Larue Rest Suite 224\nOsbaldohaven, MA 01866-08'),(102,'Jelena ','Manjencic','jelena.m@gmail.com','Munich','');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-19 21:24:11
